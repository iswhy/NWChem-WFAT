#if HAVE_CONFIG_H
#   include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>
#include <string.h>

#include "comex.h"
#include "comex_impl.h"


int comex_create_mutexes(int num)
{
        assert(0);
        return COMEX_SUCCESS;
}

int comex_destroy_mutexes()
{
        assert(0);
        return COMEX_SUCCESS;
}

int comex_lock(int mutex, int proc)
{
        assert(0);
        return COMEX_SUCCESS;
}

int comex_unlock(int mutex, int proc)
{
        assert(0);
        return COMEX_SUCCESS;
}

